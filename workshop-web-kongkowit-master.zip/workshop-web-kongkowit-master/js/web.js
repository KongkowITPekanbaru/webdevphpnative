var button = document.getElementById("tombol");
button.addEventListener('click', function () {
	nama = document.getElementById("nama_user");
	alert('Hai ' + nama.value);
})
